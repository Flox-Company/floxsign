# sign/__init__.py
from .get_name import get_name